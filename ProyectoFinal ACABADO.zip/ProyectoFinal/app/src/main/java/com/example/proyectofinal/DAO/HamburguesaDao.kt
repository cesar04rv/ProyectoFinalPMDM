package com.example.proyectofinal.DAO

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.proyectofinal.HamburguesaEntity

@Dao
interface HamburguesaDao {

    @Query("SELECT * FROM hamburguesas")
    suspend fun getHamburguesas(): List<HamburguesaEntity>

    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE)
    suspend fun addHamburguesa(hamburguesa: HamburguesaEntity)

    @Update
    suspend fun updateHamburguesa(hamburguesa: HamburguesaEntity)

    @Query("SELECT COUNT(*) FROM hamburguesas WHERE nombre = :nombre")
    suspend fun checkHamburguesaExists(nombre: String): Int

    @Query("SELECT * FROM hamburguesas WHERE id = :id LIMIT 1")
    suspend fun getHamburguesaById(id: Long): HamburguesaEntity?

    @Query("DELETE FROM hamburguesas WHERE id = :id")
    suspend fun deleteHamburguesaById(id: Long)



}
