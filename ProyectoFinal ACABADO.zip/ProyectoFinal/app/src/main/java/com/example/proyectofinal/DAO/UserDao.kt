package com.example.proyectofinal.DAO

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.proyectofinal.LOGIN.UserEntity

@Dao
interface UserDao {
    @Query("SELECT * FROM UserEntity WHERE email = :email AND password = :password LIMIT 1")
    suspend fun getUser(email: String, password: String): UserEntity?

    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE)
    suspend fun addUser(userEntity: UserEntity)

    @Query("SELECT COUNT(*) FROM UserEntity WHERE email = :email")
    suspend fun checkUserExists(email: String): Int
}
