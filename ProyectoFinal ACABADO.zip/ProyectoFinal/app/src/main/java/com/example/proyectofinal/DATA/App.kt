package com.example.proyectofinal.DATA


import android.app.Application
import androidx.room.Room
import com.example.proyectofinal.HamburguesaEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class App : Application() {
    companion object {
        lateinit var database: Database
    }

    override fun onCreate() {
        super.onCreate()

        // Initialize the database with Room
        try {
            database = Room.databaseBuilder(
                this,
                Database::class.java,
                "Database"
            )
                .fallbackToDestructiveMigration() // In case of database version mismatch
                .build()
        } catch (e: Exception) {
            // Log and handle any exception that occurs during database setup
            e.printStackTrace()
        }

//crear hamburguesa de ejemplo
        // Crear hamburguesas de ejemplo
        GlobalScope.launch(Dispatchers.IO) {
            val hamburguesaDao = database.hamburguesaDao()
            val hamburguesasExistentes = hamburguesaDao.getHamburguesas()

            if (hamburguesasExistentes.isEmpty()) {
            val hamburguesas = listOf(
                HamburguesaEntity(
                    nombre = "Cheeseburger Clásica",
                    descripcion = "Carne jugosa con queso cheddar derretido.",
                    precio = 120.0,
                    isFavorita = false,
                    imagen = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aGFtYnVyZ3Vlc2F8ZW58MHx8MHx8fDA%3D"
                ),
                HamburguesaEntity(
                    nombre = "Doble BBQ",
                    descripcion = "Dos carnes con salsa BBQ y cebolla caramelizada.",
                    precio = 150.0,
                    isFavorita = false,
                    imagen = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aGFtYnVyZ3Vlc2F8ZW58MHx8MHx8fDA%3D"
                ),
                HamburguesaEntity(
                    nombre = "Veggie Delight",
                    descripcion = "Hamburguesa de lentejas con aguacate y tomate.",
                    precio = 110.0,
                    isFavorita = false,
                    imagen = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aGFtYnVyZ3Vlc2F8ZW58MHx8MHx8fDA%3D"
                ),
                HamburguesaEntity(
                    nombre = "Picante Mexicana",
                    descripcion = "Con jalapeños, guacamole y salsa picante.",
                    precio = 130.0,
                    isFavorita = false,
                    imagen = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aGFtYnVyZ3Vlc2F8ZW58MHx8MHx8fDA%3D"
                ),
                HamburguesaEntity(
                    nombre = "Smoky Bacon",
                    descripcion = "Carne ahumada con tocino crujiente y queso suizo.",
                    precio = 140.0,
                    isFavorita = false,
                    imagen = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aGFtYnVyZ3Vlc2F8ZW58MHx8MHx8fDA%3D"
                ),
                HamburguesaEntity(
                    nombre = "Triple Monster",
                    descripcion = "Tres carnes, triple queso y salsa especial.",
                    precio = 180.0,
                    isFavorita = false,
                    imagen = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aGFtYnVyZ3Vlc2F8ZW58MHx8MHx8fDA%3D"
                )
            )


            hamburguesas.forEach { hamburguesaDao.addHamburguesa(it) }
        }}


    }
}