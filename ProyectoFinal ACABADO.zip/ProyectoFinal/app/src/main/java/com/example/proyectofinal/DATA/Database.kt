package com.example.proyectofinal.DATA
import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.proyectofinal.DAO.HamburguesaDao
import com.example.proyectofinal.DAO.UserDao
import com.example.proyectofinal.HamburguesaEntity
import com.example.proyectofinal.LOGIN.UserEntity

@Database(entities = [ UserEntity::class, HamburguesaEntity::class], version = 1)
abstract class Database: RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract  fun hamburguesaDao(): HamburguesaDao

}
