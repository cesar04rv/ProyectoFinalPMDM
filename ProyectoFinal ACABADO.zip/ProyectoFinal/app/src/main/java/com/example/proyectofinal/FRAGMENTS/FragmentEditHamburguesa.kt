package com.example.proyectofinal.FRAGMENTS

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.example.proyectofinal.DATA.App
import com.example.proyectofinal.HamburguesaEntity
import com.example.proyectofinal.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.activity.addCallback

class FragmentEditHamburguesa : Fragment() {
    private lateinit var hamburguesa: HamburguesaEntity
    private lateinit var nombreEditText: EditText
    private lateinit var descripcionEditText: EditText
    private lateinit var precioEditText: EditText
    private lateinit var urlImagenEditText: EditText
    private lateinit var saveButton: Button
    private lateinit var backgroundImageView: ImageView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_edit_hamburguesa, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Inicializar vistas
        nombreEditText = view.findViewById(R.id.nombreEditText)
        descripcionEditText = view.findViewById(R.id.descripcionEditText)
        precioEditText = view.findViewById(R.id.precioEditText)
        urlImagenEditText = view.findViewById(R.id.urlImagenEditText) // Nuevo campo para la URL de la imagen
        saveButton = view.findViewById(R.id.saveButton)
        backgroundImageView = view.findViewById(R.id.backgroundImageView)

        // Cargar la imagen de fondo con Glide
        Glide.with(requireContext())
            .load("https://img.freepik.com/foto-gratis/hamburguesa-deliciosa-estudio_23-2151846493.jpg")
            .into(backgroundImageView)

        // Obtener y mostrar la hamburguesa
        hamburguesa = arguments?.getSerializable("hamburguesa") as HamburguesaEntity
        nombreEditText.setText(hamburguesa.nombre)
        descripcionEditText.setText(hamburguesa.descripcion)
        precioEditText.setText(hamburguesa.precio.toString())
        urlImagenEditText.setText(hamburguesa.imagen) // Cargar la URL de la imagen en el EditText

        // Guardar cambios
        saveButton.setOnClickListener {
            val nombre = nombreEditText.text.toString()
            val descripcion = descripcionEditText.text.toString()
            val precio = precioEditText.text.toString().toDoubleOrNull()
            val urlImagen = urlImagenEditText.text.toString()

            if (nombre.isNotEmpty() && descripcion.isNotEmpty() && precio != null && urlImagen.isNotEmpty()) {
                // Actualizar los valores de la hamburguesa
                hamburguesa.nombre = nombre
                hamburguesa.descripcion = descripcion
                hamburguesa.precio = precio
                hamburguesa.imagen = urlImagen // Asignar la URL de la imagen

                lifecycleScope.launch(Dispatchers.IO) {
                    App.database.hamburguesaDao().updateHamburguesa(hamburguesa)
                    withContext(Dispatchers.Main) {
                        requireActivity().supportFragmentManager.beginTransaction()
                            .replace(R.id.fragment_container, FragmentFirst())
                            .addToBackStack(null)
                            .commit()
                    }
                }
            } else {
                Toast.makeText(requireContext(), "Por favor, completa todos los campos.", Toast.LENGTH_SHORT).show()
            }
        }

        // Manejar el botón de "Atrás"
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner) {
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, FragmentFirst())
                .commit()
        }
    }
}
