package com.example.proyectofinal.FRAGMENTS

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.example.proyectofinal.DATA.App
import com.example.proyectofinal.HamburgesaAdapter
import com.example.proyectofinal.R

class FragmentFirst : Fragment() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var hamburgerAdapter: HamburgesaAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_first, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Configurar el RecyclerView
        recyclerView = view.findViewById(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        // Cargar imagen de fondo con Glide
        val backgroundImageView = view.findViewById<ImageView>(R.id.backgroundImageView)
        Glide.with(this)
            .load("https://img.freepik.com/foto-gratis/hamburguesa-deliciosa-estudio_23-2151846493.jpg")
            .into(backgroundImageView)

        cargarHamburguesas() // Cargar las hamburguesas desde la base de datos
    }

    private fun cargarHamburguesas() {
        lifecycleScope.launch(Dispatchers.IO) {
            val hamburguesas = App.database.hamburguesaDao().getHamburguesas()

            withContext(Dispatchers.Main) {
                if (!::hamburgerAdapter.isInitialized) {
                    // Pasa 'this' (el fragmento actual) al adaptador
                    hamburgerAdapter = HamburgesaAdapter(hamburguesas, this@FragmentFirst)
                    recyclerView.adapter = hamburgerAdapter
                } else {
                    hamburgerAdapter.hamburguesas = hamburguesas
                    hamburgerAdapter.notifyDataSetChanged()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        cargarHamburguesas()  // Recargar las hamburguesas al volver al fragment
    }




}