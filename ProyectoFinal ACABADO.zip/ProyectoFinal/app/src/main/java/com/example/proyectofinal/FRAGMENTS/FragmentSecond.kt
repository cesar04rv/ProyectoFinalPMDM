package com.example.proyectofinal.FRAGMENTS

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.example.proyectofinal.DATA.App
import com.example.proyectofinal.HamburguesaEntity
import com.example.proyectofinal.R
import com.example.proyectofinal.databinding.FragmentSecondBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.activity.addCallback

class FragmentSecond : Fragment() {

    private lateinit var binding: FragmentSecondBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentSecondBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Obtener el ImageView para el fondo
        val backgroundImageView: ImageView = view.findViewById(R.id.backgroundImageView)

        // Cargar la imagen de fondo con Glide
        Glide.with(requireContext())
            .load("https://img.freepik.com/foto-gratis/hamburguesa-deliciosa-estudio_23-2151846493.jpg")
            .into(backgroundImageView)

        // Obtenemos el botón de guardar
        val saveButton: Button = binding.btnSaveHamburguesa

        // Configuramos el clic del botón para guardar la nueva hamburguesa
        saveButton.setOnClickListener {
            val nombre = binding.editTextNombre.text.toString()
            val descripcion = binding.editTextDescripcion.text.toString()
            val precio = binding.editTextPrecio.text.toString().toDoubleOrNull()
            val urlImagen = binding.editTextUrlImagen.text.toString() // Obtener la URL de la imagen

            if (nombre.isNotEmpty() && descripcion.isNotEmpty() && precio != null && urlImagen.isNotEmpty()) {
                // Crear la hamburguesa
                val nuevaHamburguesa = HamburguesaEntity(
                    nombre = nombre,
                    descripcion = descripcion,
                    precio = precio,
                    imagen = urlImagen // Usar la URL proporcionada
                )

                // Guardar la hamburguesa en la base de datos
                saveHamburguesa(nuevaHamburguesa)
            } else {
                Toast.makeText(
                    requireContext(),
                    "Por favor, completa todos los campos.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

        private fun saveHamburguesa(hamburguesa: HamburguesaEntity) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                // Agregar la hamburguesa a la base de datos
                App.database.hamburguesaDao().addHamburguesa(hamburguesa)

                withContext(Dispatchers.Main) {
                    Toast.makeText(requireContext(), "Hamburguesa creada con éxito.", Toast.LENGTH_SHORT).show()
                    clearFields()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    Toast.makeText(requireContext(), "Error al crear la hamburguesa.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun clearFields() {
        // Limpiar los campos después de guardar
        binding.editTextNombre.text.clear()
        binding.editTextDescripcion.text.clear()
        binding.editTextPrecio.text.clear()
    }
}
