package com.example.proyectofinal.FRAGMENTS

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.example.proyectofinal.MUSIC.MusicService
import com.example.proyectofinal.R

class FragmentThird : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_third, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val btnPlay = view.findViewById<Button>(R.id.btnPlay)
        val btnPause = view.findViewById<Button>(R.id.btnPause)
        // Cargar imagen de fondo con Glide
        val backgroundImageView = view.findViewById<ImageView>(R.id.backgroundImageView)
        Glide.with(this)
            .load("https://img.freepik.com/foto-gratis/hamburguesa-deliciosa-estudio_23-2151846493.jpg")
            .into(backgroundImageView)

        btnPlay.setOnClickListener {
            val intent = Intent(requireContext(), MusicService::class.java)
            intent.action = "PLAY"
            requireActivity().startService(intent)
        }

        btnPause.setOnClickListener {
            val intent = Intent(requireContext(), MusicService::class.java)
            intent.action = "PAUSE"
            requireActivity().startService(intent)
        }
    }
}
