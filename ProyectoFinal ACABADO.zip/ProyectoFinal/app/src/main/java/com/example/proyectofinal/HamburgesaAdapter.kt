package com.example.proyectofinal

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.proyectofinal.DATA.App
import com.example.proyectofinal.FRAGMENTS.FragmentEditHamburguesa
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HamburgesaAdapter(var hamburguesas: List<HamburguesaEntity>, val fragment: Fragment) :
    RecyclerView.Adapter<HamburgesaAdapter.HamburgerViewHolder>() {

    class HamburgerViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imageView: ImageView = view.findViewById(R.id.hamburguesa_imagen)
        val nombreView: TextView = view.findViewById(R.id.hamburguesa_nombre)
        val descripcionView: TextView = view.findViewById(R.id.hamburguesa_descripcion)
        val precioView: TextView = view.findViewById(R.id.hamburguesa_precio)
        val cardView: View = view.findViewById(R.id.card_view)
        val deletebutton: ImageView = view.findViewById(R.id.deleteButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HamburgerViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.card_item, parent, false)
        return HamburgerViewHolder(view)
    }

    override fun onBindViewHolder(holder: HamburgerViewHolder, position: Int) {
        val hamburguesa = hamburguesas[position]

        holder.nombreView.text = hamburguesa.nombre
        holder.descripcionView.text = hamburguesa.descripcion
        holder.precioView.text = "${hamburguesa.precio}€"

        Glide.with(holder.imageView.context)
            .load(hamburguesa.imagen) // Usar la URL de la hamburguesa
            .into(holder.imageView)

        // Acción para editar la hamburguesa (navegar al fragmento de edición)
        holder.cardView.setOnClickListener {
            val fragmentTransaction = fragment.parentFragmentManager.beginTransaction()
            val fragmentEdit = FragmentEditHamburguesa()

            // Pasar la hamburguesa al fragmento de edición
            val bundle = Bundle()
            bundle.putSerializable("hamburguesa", hamburguesa)
            fragmentEdit.arguments = bundle

            fragmentTransaction.replace(R.id.fragment_container, fragmentEdit)
            fragmentTransaction.addToBackStack(null) // Añadir a la pila de retroceso
            fragmentTransaction.commit()
        }

        // Acción para eliminar la hamburguesa (borrarla de la base de datos)
        holder.deletebutton.setOnClickListener {
            GlobalScope.launch(Dispatchers.IO) {
                App.database.hamburguesaDao().deleteHamburguesaById(hamburguesa.id)
                withContext(Dispatchers.Main) {
                    hamburguesas = hamburguesas - hamburguesa
                    notifyDataSetChanged() // Actualizar la vista
                }
            }
        }
    }

    override fun getItemCount() = hamburguesas.size
}
