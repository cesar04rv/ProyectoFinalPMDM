package com.example.proyectofinal

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "hamburguesas")
data class HamburguesaEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    var nombre: String? = "",
    var descripcion: String? = "",
    var precio: Double? = 0.0,
    var isFavorita: Boolean? = false,
    var imagen: String? = ""
) : Serializable
