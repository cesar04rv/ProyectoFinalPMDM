package com.example.proyectofinal.LOGIN

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.example.proyectofinal.DATA.App
import com.example.proyectofinal.MainActivity
import com.example.proyectofinal.R
import com.example.proyectofinal.databinding.ActivityLoginBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences = getPreferences(Context.MODE_PRIVATE)

        // Cargar la imagen de fondo desde una URL con Glide
        val imageUrl = "https://img.freepik.com/foto-gratis/hamburguesa-deliciosa-estudio_23-2151846493.jpg"
        Glide.with(this)
            .load(imageUrl)
            .into(binding.imagendefondo)

        // Recuperar los datos enviados desde RegisterActivity (si existen)
        val receivedEmail = intent.getStringExtra("EXTRA_EMAIL")
        val receivedPassword = intent.getStringExtra("EXTRA_PASSWORD")

        if (!receivedEmail.isNullOrEmpty() && !receivedPassword.isNullOrEmpty()) {
            // Si vienen datos del registro, sobrescribe SharedPreferences y rellena los EditText
            with(sharedPreferences.edit()) {
                putString(getString(R.string.Mail), receivedEmail)
                putString(getString(R.string.password), receivedPassword)
                putBoolean(getString(R.string.remember), false) // No marcar "Recordar" automáticamente
                apply()
            }
            binding.Mail.setText(receivedEmail)
            binding.Password.setText(receivedPassword)
        } else {
            // Si no vienen datos del registro, carga lo que esté guardado en SharedPreferences
            val storedEmail = sharedPreferences.getString(getString(R.string.Mail), null)
            val storedPassword = sharedPreferences.getString(getString(R.string.password), null)
            val rememberMe = sharedPreferences.getBoolean(getString(R.string.remember), false)

            if (rememberMe) {
                binding.checkbox.isChecked = true
                binding.Mail.setText(storedEmail)
                binding.Password.setText(storedPassword)
            }
        }

        setupLoginLogic()
    }



    private fun setupLoginLogic() {
        val email = binding.Mail
        val password = binding.Password
        val checkbox = binding.checkbox
        val storedEmail = sharedPreferences.getString(getString(R.string.Mail), null)
        val storedPassword = sharedPreferences.getString(getString(R.string.password), null)
        val rememberMe = sharedPreferences.getBoolean(getString(R.string.remember), false)

        if (rememberMe) {
            checkbox.isChecked = true
        }
        if (storedEmail != null && storedPassword != null) {
            email.setText(storedEmail)
            password.setText(storedPassword)
        }

        binding.Register.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }

        binding.Login.setOnClickListener {
            lifecycleScope.launch {
                val emailText = email.text.toString()
                val passwordText = password.text.toString()
                val user = user(emailText, passwordText)
                if (user != null && emailText == user.email && passwordText == user.password) {
                    with(sharedPreferences.edit()) {
                        if (checkbox.isChecked) {
                            putString(getString(R.string.Mail), emailText)
                            putString(getString(R.string.password), passwordText)
                            putBoolean(getString(R.string.remember), true)
                        } else {
                            remove(getString(R.string.Mail))
                            remove(getString(R.string.password))
                            putBoolean(getString(R.string.remember), false)
                        }
                        apply()
                    }
                    Toast.makeText(this@LoginActivity, "Bienvenido ${user.name}", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                } else {
                    Toast.makeText(this@LoginActivity, "Credenciales incorrectas", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private suspend fun user(email: String, password: String): UserEntity? {
        return withContext(Dispatchers.IO) {
            App.database.userDao().getUser(email.trim(), password)
        }
    }
}
