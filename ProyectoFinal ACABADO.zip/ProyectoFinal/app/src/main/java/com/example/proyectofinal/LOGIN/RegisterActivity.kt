package com.example.proyectofinal.LOGIN

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.example.proyectofinal.DATA.App
import com.example.proyectofinal.R
import com.example.proyectofinal.databinding.ActivityRegisterBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences = getPreferences(Context.MODE_PRIVATE)

        // Cargar la imagen de fondo usando Glide
        Glide.with(this)
            .load("https://img.freepik.com/foto-gratis/hamburguesa-deliciosa-estudio_23-2151846493.jpg")
            .into(binding.imagendefondo)

        setupRegistrationLogic()

        // OnClickListener para el TextView de "Register"
        binding.Register.setOnClickListener {
            // Cuando se hace clic, se inicia la LoginActivity
            startActivity(Intent(this@RegisterActivity, LoginActivity::class.java))
        }
    }

    private fun setupRegistrationLogic() {
        binding.btnRegisterLogin.setOnClickListener {
            val userName = binding.Name.text.toString()
            val userEmail = binding.etRegisterEmail.text.toString()
            val userPassword = binding.etRegisterPassword.text.toString()

            if (userName.isNotEmpty() && userEmail.isNotEmpty() && userPassword.isNotEmpty()) {
                lifecycleScope.launch(Dispatchers.IO) {
                    val existingUser = App.database.userDao().getUser(userEmail, userPassword)

                    if (existingUser == null) {
                        val newUser = UserEntity(email = userEmail, name = userName, password = userPassword)
                        App.database.userDao().addUser(newUser)

                        runOnUiThread {
                            Toast.makeText(this@RegisterActivity, "Registro exitoso", Toast.LENGTH_SHORT).show()

                            // Enviar los datos al LoginActivity usando Intent
                            val intent = Intent(this@RegisterActivity, LoginActivity::class.java)
                            intent.putExtra("EXTRA_EMAIL", userEmail)
                            intent.putExtra("EXTRA_PASSWORD", userPassword)
                            startActivity(intent)
                            finish() // Cerrar esta actividad
                        }
                    } else {
                        runOnUiThread {
                            Toast.makeText(this@RegisterActivity, "Usuario ya registrado", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            } else {
                Toast.makeText(this, "Datos inválidos", Toast.LENGTH_SHORT).show()
            }
        }
    }




}
