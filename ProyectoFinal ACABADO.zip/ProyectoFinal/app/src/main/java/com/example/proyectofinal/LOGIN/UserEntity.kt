package com.example.proyectofinal.LOGIN

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "UserEntity")
data class UserEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val email: String? = "",
    val name: String? = "",
    val password: String? = ""
) : Serializable
