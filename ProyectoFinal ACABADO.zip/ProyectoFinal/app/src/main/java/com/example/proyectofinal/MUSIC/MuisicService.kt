package com.example.proyectofinal.MUSIC

import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.os.IBinder
import com.example.proyectofinal.R

class MusicService : Service() {
    private var mediaPlayer: MediaPlayer? = null
    private var lastPosition: Int = 0

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (mediaPlayer == null) {
            mediaPlayer = MediaPlayer.create(this, R.raw.repartiendo_arte) // Carga el audio desde raw
            mediaPlayer?.isLooping = true  // Para que se repita al terminar
        }

        when (intent?.action) {
            "PLAY" -> {
                mediaPlayer?.seekTo(lastPosition)
                mediaPlayer?.start()
            }
            "PAUSE" -> {
                mediaPlayer?.let {
                    if (it.isPlaying) {
                        lastPosition = it.currentPosition
                        it.pause()
                    }
                }
            }
            "STOP" -> {
                mediaPlayer?.stop()
                mediaPlayer?.release()
                mediaPlayer = null
                stopSelf() // Detiene el servicio
            }
        }

        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.release()
        mediaPlayer = null
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
