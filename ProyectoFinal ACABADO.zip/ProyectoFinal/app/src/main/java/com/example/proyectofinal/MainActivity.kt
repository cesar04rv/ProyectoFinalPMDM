package com.example.proyectofinal

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.proyectofinal.FRAGMENTS.FragmentFirst
import com.example.proyectofinal.FRAGMENTS.FragmentSecond
import com.example.proyectofinal.FRAGMENTS.FragmentThird
import com.google.android.material.bottomnavigation.BottomNavigationView


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, FragmentFirst())
                .commit()
        }

        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottom_navigation)
        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.fragment_container -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragment_container, FragmentFirst())
                        .commit()
                    true
                }

                R.id.fragment_create_hamburguesa -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragment_container, FragmentSecond())
                        .commit()
                    true
                }

                R.id.nav_reproductor -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragment_container, FragmentThird())
                        .commit()
                    true
                }

                else -> false
            }
        }

    }
}